#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @Author: Boat
"""
连接hive集群，并可通过getData()方法读取hive表数据
"""
from pyhive import hive
import pandas as pd


class hiveInit:
    # 初始化，设置hive相关参数
    def __init__(self, env):
        if env == 'test':
            # 测试集群
            self.host = '10.201.4.50'
            self.port = 10000
            self.username = 'deploy_man'
            self.password = 'A3$iwGouLa!nJ&s6'
        elif env == 'online':
            # 生产集群
            self.host = '172.20.22.11'
            self.port = 10000
            self.username = 'deploy_man'
            self.password = 'puZV8f!*$0!aOOzs'
        else:
            raise NameError("未定义环境参数inv，或定义错误。inv='test'表示hive测试集群；inv='online'表示hive线上集群")


    # 利用dataframe格式读取hive数据
    def getData(self, sql):
        # 参数说明
        # auth='LDAP'：为Password服务，不加会报错的
        # ValueError: Password should be set if and only if in LDAP or CUSTOM mode; Remove password or use one of those modes
        conn = hive.connect(host=self.host, port=self.port, username=self.username, password=self.password, auth='LDAP')
        result = pd.read_sql(sql, conn)
        conn.close()

        return result




if __name__ == '__main__':
    hiveStart = hiveInit(env='test')
    info_hql = '''select * from dwd.dwd_itemcf_score_standardized t limit 1000'''
    info = hiveStart.getData(info_hql)
    print(info)
