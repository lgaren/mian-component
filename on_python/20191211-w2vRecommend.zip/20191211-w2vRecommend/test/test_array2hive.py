import numpy as np
import pandas as pd

vec = np.array(list(range(10)))

column2 = pd.Series([vec]*10)
column1 = pd.Series(np.array(list(range(10))))




df = pd.DataFrame({'c1':column1,'c2':column2})
df['c2'] = df['c2'].astype('str').apply(lambda x:x[1:-1])
print(df)
df.to_csv(path_or_buf='test.csv',sep="\u0001",header=False,index=False)



'''
CREATE EXTERNAL TABLE IF NOT EXISTS  `default.default_test_array`(
  `id` int COMMENT 'id', 
  `array_test` array<int> COMMENT 'test1'
	)
COMMENT 'test'
row format delimited fields terminated by '\u0001' 
collection items terminated by ' '
LOCATION
  'hdfs://nameservice1/dw/default/default_test_array';
'''