#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Dec 11 2019

@author: jiongwu

从hive中读取用户浏览，并进行word2vec训练，保存训练好的模型
"""
import os
import sys
import gensim

from gensim.corpora import WikiCorpus
import pandas as pd
import numpy as np
from gensim.models import Word2Vec


from hiveInit import hiveInit

hiveStart = hiveInit(env='test')
info_hql = """SELECT pid_list,pname_list from default.dml_word2vec_product_clicklist t WHERE t.par_day='20191210'"""
info = hiveStart.getData(info_hql)


info['pid_list'] = info['pid_list'].astype(dtype='str')
info['pname_list'] = info['pname_list'].astype(dtype='str')



sentencesDf = info['pname_list'].apply(lambda x:x[1:-1]).apply(lambda x: [p[1:-1] for p in x.split(',')])  # 去掉[]、""，并将info['pid_list']转换成列表形式
sentencesList = []
for plist in sentencesDf:
    sentencesList.append(plist)



model = Word2Vec(sentences=None, size=200,
                 window=10, negative=10, sg = 1, hs = 0,
                 workers=3, min_alpha=0.00001, iter=5
                 )
# model = Word2Vec(window = 10, sg = 1, hs = 0,
#                  negative = 10, # for negative sampling
#                  alpha=0.03, min_alpha=0.0007,
#                  seed = 14)


model.build_vocab(sentencesList)

model.train(sentencesList, total_examples=model.corpus_count, epochs=model.epochs)


print(model.most_similar('上海影视乐园'))
# model.wv.vocab.keys()



model.save("./target/w2v_model.bin")  # 可载入后接着训练的模型
# #This saved model can be loaded again using :func:`~gensim.models.word2vec.Word2Vec.load`, which supportsonline training and getting vectors for vocabulary words.
model.wv.save_word2vec_format("./target/w2v_vec.bin", binary=False)  # 只存储向量，不可继续训练，节约空间